dofile 'interpreters/luabase.lua'
return MakeLuaInterpreter(5.2, ' 5.2')
