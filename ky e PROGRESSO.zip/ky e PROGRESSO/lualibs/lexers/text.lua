-- Copyright 2006-2016 Mitchell mitchell.att.foicica.com. See LICENSE.
-- Text LPeg lexer.

local M = {_NAME = 'text'}

return M
