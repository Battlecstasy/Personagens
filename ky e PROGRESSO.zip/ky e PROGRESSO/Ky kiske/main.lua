
local ky_vida=100
local ky_velocidade=1
local ky_gravidade=1
local ky_andar=100
local ky_anim_frame = 1
local ky_pos_x = 30
local ky_pos_y = 50
local ky_walk = {}
local ky_anim_time = 0
local ky_crouch = {}
function love.load()
  for x = 1, 110 do -- carrega as imagens da animação
    ky_walk[x] = love.graphics.newImage("kyImagens/ky (" .. (x) .. ").png")
  end
  ky_walk[20] = ky_walk[18]
  ky_walk[19] = ky_walk[18]
  ky_walk[18] = ky_walk[17]
  for x = 1, 2 do
    ky_crouch[x] = love.graphics.newImage("kyImagens/ky (" .. (x) .. ").png")
end
end

function love.update(dt)
  if love.keyboard.isDown("right") then
    ky_pos_x = ky_pos_x + (150 * dt) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.11 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame > 5 then
      ky_anim_frame = 1
    end
  end
    
  if love.keyboard.isDown("left") then
    ky_pos_x = ky_pos_x + (-140 * dt) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 6 or ky_anim_frame > 20 then
      ky_anim_frame = 7
    end
  end
  
  
  if love.keyboard.isDown("down") then
    ky_pos_y = ky_pos_y + (-100 * dt)
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame > 1 then
      ky_anim_frame = 0
    end
  end
end


function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.draw(ky_walk[ky_anim_frame], ky_pos_x, ky_pos_y)
  --love.graphics.draw(ky_crouch[ky_anim_frame], ky_pos_x, ky_pos_y)
end