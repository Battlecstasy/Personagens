
local ky_vida=100
local ky_velocidade=1
local ky_gravidade=1
local ky_andar=100
local ky_anim_frame = 1
local ky_pos_x = 200
local ky_pos_y = 400
local ky_walk = {}
local ky_anim_time = 0
local ky_crouch = {}
local ky_butpressed = false
local ky_anim_type = {0,0}
local ky_anim_timepassed = {0.11, 0.09, 0.15, 0.09}
local isAttacking

function love.load()
  for x = 1, 199 do -- carrega as imagens da animação
    ky_walk[x] = love.graphics.newImage("kyImagens/ky (" .. (x) .. ").png")
  end
end

--[[function love.keypressed(key)
  if key == "right" then
    ky_anim_type[1] = 1
    if ky_anim_frame > 5 then
      ky_anim_frame = 1
    end

  elseif key == "left" then
    ky_anim_type[1] = 2
    if ky_anim_frame < 6 or ky_anim_frame > 1 then
      ky_anim_frame = 7
    end

  elseif key == "down" then
    ky_anim_type[1] = 3
    if ky_anim_frame < 39 then
      ky_anim_frame = 39
    end
    if ky_anim_frame == 44 then
      ky_anim_frame = 42
    end
    if ky_anim_frame > 44 then
      ky_anim_frame = 39
    end

  elseif key == "a" then
    ky_anim_type[1] = 4
    ky_butpressed = true
    if ky_anim_frame < 109 or ky_anim_frame > 117 then
      ky_anim_frame = 109
    end
  end
end

function love.keyreleased(key)
  ky_anim_type[1] = 0
end

function love.update(dt)
  -- PARA REVERTER DELETE ISSO --
  if ky_anim_type[1] == 1 then
    ky_pos_x = ky_pos_x + (150 * dt) -- movimenta o personagem
  elseif ky_anim_type[1] == 2 then
    ky_pos_x = ky_pos_x + (-140 * dt)
  end
  if ky_anim_type[1] ~= ky_anim_type[2] then
    ky_anim_type[2] = ky_anim_type[1]
    ky_anim_time = 0
  end
  if ky_anim_type[1] ~= 0 and ky_anim_time > ky_anim_timepassed[ky_anim_type[1]] --[[then -- quando acumular mais de 0.1
    ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
    ky_anim_time = 0
  end
  ky_anim_time = ky_anim_time + dt
  ]]
  -- PARA REVERTER DELETE ISSO ^--
function love.update(dt)
  if love.keyboard.isDown("right") and not isAttacking then
    ky_pos_x = ky_pos_x + (150 * dt) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.11 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame > 5 then
      ky_anim_frame = 1
    end
  

  elseif love.keyboard.isDown ("left") and not isAttacking  then
    ky_pos_x = ky_pos_x + (-140 * dt) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 6 or ky_anim_frame > 18 then
      ky_anim_frame = 7
    end
  


  elseif love.keyboard.isDown("down") and not isAttacking  then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.15 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 39 then
      ky_anim_frame = 39
    end
   if ky_anim_frame == 44 then
      ky_anim_frame = 42
    end
    if ky_anim_frame > 44 then
      ky_anim_frame = 39
    end
  else then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 21 or ky_anim_frame > 29 then
      ky_anim_frame = 21
    end
  end

  if isAttacking then
    ky_pos_x = ky_pos_x + (4 * dt) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
      end
    if ky_anim_frame < 109 or ky_anim_frame > 121 then
    ky_anim_frame = 109
    end
    if ky_anim_frame == 120 then 
    isAttacking = false
    end
  end
end

function love.keypressed(key)
  if(key == "a" and not isAttacking) then
    isAttacking = true
  end  
end

function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.draw(ky_walk[ky_anim_frame], ky_pos_x, ky_pos_y, 0, 1, 1, ky_walk[ky_anim_frame]:getWidth(), ky_walk[ky_anim_frame]:getHeight())
  --love.graphics.draw(ky_crouch[ky_anim_frame], ky_pos_x, ky_pos_y)
end