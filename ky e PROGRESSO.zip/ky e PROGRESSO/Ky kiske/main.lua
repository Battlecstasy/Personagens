local ky_vida=100
local ky_velocity_y=0
local ky_gravity=1550
local ky_andar=100
local ky_anim_frame = 1
local stage_pos_y = 500
local ky_pos_x = 350
local ky_pos_y = stage_pos_y 
local ky_walk = {}
local ky_anim_time = 0
local ky_crouch = {}
local ky_butpressed = false
local ky_anim_type = {0,0}
local ky_anim_timepassed = {0.11, 0.09, 0.15, 0.09}
local wry
local bofa
local kysize = 0.8 
local disjointx = 0
local disjointy = 0
local la
local ma
local ha
local sa
local onair
local crouch
local forward = false
local back = false
local facing = true
local direction
local p2x = 400
local size
local onAction = false
local isAttacking = false
local onHitstun = false
local onBlockstun = false
local onAir = false

function love.load()
  
  for x = 1, 199 do -- carrega as imagens da animação
    ky_walk[x] = love.graphics.newImage("kyImagens/ky (" .. (x) .. ").png")
  end
  
end

function love.update(dt)
  if isAttacking  or onBlockstun or onHitstun or onAir then
    onAction=true
  else
    onAction=false
    end
  
  if (p2x >= ky_pos_x and love.keyboard.isDown("right")) or (p2x < ky_pos_x and love.keyboard.isDown("left")) then
    forward= true
  else
    forward = false
  end
   if (p2x < ky_pos_x and love.keyboard.isDown("right")) or (p2x >= ky_pos_x and love.keyboard.isDown("left")) then
    back= true
  else
    back = false
  end
  if p2x > ky_pos_x and not onAction then
    facing= true
    end
   if p2x < ky_pos_x and not onAction then
    facing = false
    end
    
  if facing then
    direction = 1
  else
    direction = -1
  end
  if isAttacking == false then
    la= false
    ma= false
    sa= false
    ha= false
  end
  if love.keyboard.isDown("up") and not onAction  then
    ky_velocity_y=600
    ky_pos_y = ky_pos_y - 1
   
   
   
  elseif forward and not isAttacking then
    ky_pos_x = ky_pos_x + (150 * dt*kysize*direction)
    ky_anim_time = ky_anim_time + dt
    disjointx =0
    disjointy =0
    if ky_anim_time > 0.11 then
      ky_anim_frame = ky_anim_frame + 1 
      ky_anim_time = 0
end
    if ky_anim_frame > 5 then
      ky_anim_frame = 1
      end
  
  
  elseif back and not isAttacking  then
    ky_pos_x = ky_pos_x + (-140 * dt*kysize*direction)
    ky_anim_time = ky_anim_time + dt
    disjointx =0
    disjointy =0
    if ky_anim_time > 0.09 then 
      ky_anim_frame = ky_anim_frame + 1 
      ky_anim_time = 0
    end
    if ky_anim_frame < 6 or ky_anim_frame > 18 then
      ky_anim_frame = 7
    end
  
  
  
  
  
  
  elseif isAttacking and ma then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
   if ky_anim_frame == 111 then
     wry = true
   end
    if ky_anim_frame == 112  and wry then
      disjointy = 28
      ky_pos_x = ky_pos_x
      disjointx = 38*direction
      wry = false
    end
    if ky_anim_frame == 117 then
      wry= true
     end
    if ky_anim_frame == 118 and wry then
     disjointy = 0
     disjointx = 0
     wry = false
     end
    if ky_anim_frame < 108 or ky_anim_frame > 121 then
    ky_anim_frame = 109
  end
  if love.keyboard.isDown("o") and ky_anim_frame > 115 then
    isAttacking = false
    end
    if ky_anim_frame == 120 then 
    isAttacking = false
    end
 
 
 
 
 
 
elseif isAttacking and la then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.15 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame == 111 then
     wry = true
   end
    if ky_anim_frame == 112  and wry then
      disjointy = 28
      ky_pos_x = ky_pos_x
      disjointx = 38*direction
      wry = false
    end
    if ky_anim_frame == 117 then
      wry= true
     end
    if ky_anim_frame == 118 and wry then
     disjointy = 0
     disjointx = 0
     wry = false
     end
    if ky_anim_frame < 105 or ky_anim_frame > 109 then
    ky_anim_frame = 105
  end
  if love.keyboard.isDown("o") and ky_anim_frame > 106 then
    isAttacking = false
    end
    if ky_anim_frame == 108 then 
    isAttacking = false
    end
 
 elseif isAttacking and ha then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.14 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame == 124 then
     wry = true
     
   elseif ky_anim_frame == 125  and wry then
      disjointy = 0
      ky_pos_x = ky_pos_x + 0*kysize*direction
      disjointx = 70*direction
      wry = false
    elseif ky_anim_frame == 126 then
      wry= true
    elseif ky_anim_frame == 127 and wry then
     disjointy = 0
     disjointx = disjointx + 7
     wry = false
     bofa = true
   elseif ky_anim_frame == 128 and bofa then
     disjointy = 0
     disjointx = disjointx + 5
     bofa = false
     end
    if ky_anim_frame < 123 or ky_anim_frame > 129 then
    ky_anim_frame = 123
  end
  if love.keyboard.isDown("o") and ky_anim_frame > 115 then
    isAttacking = false
    end
    if ky_anim_frame == 128 then 
    isAttacking = false
    disjointx = 0
    disjointy = 0
    end
 
 
 
 
 
 
 
 
 elseif isAttacking and sa then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame == 111 then
     wry = true
   end
    if ky_anim_frame == 112  and wry then
      disjointy = 28
      ky_pos_x = ky_pos_x + 50*direction
      disjointx = 58*direction
      wry = false
    end
    if ky_anim_frame == 117 then
      wry= true
     end
    if ky_anim_frame == 118 and wry then
     disjointy = 0
     disjointx = 0
     wry = false
     end
    if ky_anim_frame < 108 or ky_anim_frame > 121 then
    ky_anim_frame = 109
  end
  if love.keyboard.isDown("o") and ky_anim_frame > 115 then
    isAttacking = false
    end
    if ky_anim_frame == 120 then 
    isAttacking = false
    end
 
 
 
 
 
  elseif love.keyboard.isDown("down") and not isAttacking  then
    ky_anim_time = ky_anim_time + dt
    
    disjointx =0
    disjointy =0
    if ky_anim_time > 0.15 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 39 then
      ky_anim_frame = 39
    end
   if ky_anim_frame == 44 then
      ky_anim_frame = 42
    end
    if ky_anim_frame > 44 then
      ky_anim_frame = 39
    end
  else
    ky_anim_time = ky_anim_time + dt
    disjointx = 0
    disjointy = 0
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 21 or ky_anim_frame > 29 then
      ky_anim_frame = 21
    end
end
if ky_pos_y > stage_pos_y then
    ky_pos_y= stage_pos_y
end
if ky_pos_y < stage_pos_y then
  onAir=true
  ky_pos_y= ky_pos_y - ky_velocity_y*dt
  ky_velocity_y=ky_velocity_y - ky_gravity*dt
else
  onAir=false
 
end
end






function love.keypressed(key)
  if(key == "u" ) then
    forward= true
  elseif(key == "j" ) then
    forward = false
    end
  if(key == "a" and not isAttacking) then
    isAttacking = true
    la=true
  
  elseif(key == "s" and not isAttacking) then
    isAttacking = true
    ma=true
  
    elseif(key == "d" and not isAttacking) then
    isAttacking = true
    ha=true
    
    elseif(key == "f" and not isAttacking) then
    isAttacking = true
    sa=true
  end  
end




function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.setBackgroundColor( 100, 100, 255 )
  love.graphics.draw(ky_walk[ky_anim_frame],disjointx+ky_pos_x+ky_walk[ky_anim_frame]:getWidth()/2*direction, ky_pos_y + disjointy , 0, kysize*direction , kysize, ky_walk[ky_anim_frame]:getWidth(), ky_walk[ky_anim_frame]:getHeight())
  love.graphics.setBackgroundColor( 13, 14, 14 )
  --POSICAO DO KY NA TELA--
  love.graphics.print(ky_pos_x.." "..ky_pos_y, 100,100)
  if la then
  love.graphics.print("la", 100,120)
  end
 if ma  then
  love.graphics.print("ma", 120,120)
  end
 if ha  then
  love.graphics.print("ha", 140,120)
end
 if sa then
  love.graphics.print("sa", 160,120)
end

  --love.graphics.draw(ky_crouch[ky_anim_frame], ky_pos_x, ky_pos_y)
end