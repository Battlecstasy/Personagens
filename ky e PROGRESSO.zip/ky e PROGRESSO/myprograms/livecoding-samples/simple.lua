print("Begin")
for i = 1, 3 do
  print(i)
end
print("End")