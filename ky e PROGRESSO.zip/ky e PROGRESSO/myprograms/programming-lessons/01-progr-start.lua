--[[ [previous](00-contents.lua) | [contents](00-contents.lua) | [next](02-controls.lua)

# Hi there!

It is very exciting that you want to learn to program. My son, who will be 8 years old soon, wants to become a programmer like his dad and his older brother. That is why we decided to create these lessons that will help him and you to enter an exciting world of programming.

Remember the time you were learning to read? You started from ABCs. Then you were putting letters in simple words and progressed to long sentences. In a similar way we will start from the basics that will help you understand how programming works. Like with anything new, we have to learn programming ABCs. It will not be boring, trust me.

Click the [next](02-controls.lua) link at the top of the screen to get started.
]]